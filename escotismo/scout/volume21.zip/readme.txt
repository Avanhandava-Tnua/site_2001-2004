 ################################
 #                              #      
 #  BBB            PPP          #        More than
 #  B               P           #        1000 images and pictures
 #  BBB             P           #        about 
 #    B             P           #        SCOUTING
 #  BBB C O U T    PPP M A G E  #
 #                              #
 ################################

     The archives are in ZIP format. You can extract the images using,
for instance, the Winzip or the pkunzip.

     The images are in TIFF format (lzw compress) with a 300 dpi
resolution and are wonderful ideas to put in documents, newspapers,
wallpapers, and so on.
     The TIFF format is compatible with most of the programs that
exist on the market, namely:
            -Microsoft Word
            -Microsoft Publisher
            -PageMaker
            -QuarkXPress
            -and others

      The images can be edited using a image processor, for instance
the Paint Shop Pro.

      You can get the Paint Shop Pro and the Winzip in:

		http://www.tucows.com
		http://www.shareware.com


          Visit us reguraly. Every month added news images.
        _____________________________________________________
       |       |                                             |
       |  WWW: | http://student.dei.uc.pt/~alexp/scoutimage  |
       |_______|_____________________________________________| 
       |       |                                             |
       |email: | alexp@student.dei.uc.pt                     |
       |_______|_____________________________________________|